# Group Assignment Contribution Tracker

Track who did what in a group project — task by task.

## Team & Responsibilities

| Member | Role | Branch |
|--------|------|--------|
| Member 1 | React Frontend | `feature/react-frontend` |
| Member 2 | Node.js CRUD + SQLite | `feature/node-crud` |
| Member 3 | Python Analytics + Git Lead | `feature/python-analytics` |

## Tech Stack
- **Frontend:** React (Vite) — port 5173
- **Backend (CRUD):** Node.js + Express + SQLite — port 3001
- **Backend (Analytics):** Python Flask — port 5001

## Running the Project

### 1. Node.js Backend (Member 2)
```bash
cd backend-node
npm install
node server.js
```

### 2. Python Analytics (Member 3)
```bash
cd backend-python
pip install -r requirements.txt
python app.py
```

### 3. React Frontend (Member 1)
```bash
cd client
npm install
npm run dev
```

## Git Workflow

```
main        — production-ready code (merge here at EOD demo)
  └── dev   — integration branch (merge features here at Hour 5)
        ├── feature/react-frontend   (Member 1)
        ├── feature/node-crud        (Member 2)
        └── feature/python-analytics (Member 3)
```

Commit to your feature branch every 45–60 minutes.  
At Hour 5: merge all features → dev → test → merge dev → main.

## Analytics API

`GET http://localhost:5001/api/analytics/:project_id`

**Response:**
```json
{
  "project_name": "Group Contribution Tracker",
  "total_tasks": 9,
  "completed_tasks": 7,
  "contributions": [
    {
      "member_id": 1,
      "member_name": "Alice",
      "assigned_tasks": 3,
      "completed_tasks": 2,
      "contribution_percentage": 22.2
    }
  ]
}
```

## Testing Analytics Without Node Server

```bash
cd backend-python
python seed_test.py   # creates a test database.db
python app.py         # starts Flask on port 5001
```
Then open: http://localhost:5001/api/analytics/1
