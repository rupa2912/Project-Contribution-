from flask import Flask, jsonify
from flask_cors import CORS
import sqlite3
import os

app = Flask(__name__)
CORS(app)  # Allow React frontend to access this service

# Connect to the SQLite database created by Member 2's Node server
DB_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '../backend-node/database.db'))

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # Enables column access by name
    return conn

@app.route('/api/analytics/<int:project_id>', methods=['GET'])
def get_project_summary(project_id):
    try:
        conn = get_db_connection()
        
        # 1. Fetch Project Details
        project = conn.execute('SELECT * FROM projects WHERE id = ?', (project_id,)).fetchone()
        if not project:
            conn.close()
            return jsonify({"error": "Project not found"}), 404

        # 2. Fetch Members and Tasks
        members = conn.execute('SELECT * FROM members WHERE project_id = ?', (project_id,)).fetchall()
        tasks = conn.execute('SELECT * FROM tasks WHERE project_id = ?', (project_id,)).fetchall()
        
        conn.close()
        
        total_tasks = len(tasks)
        completed_tasks = sum(1 for t in tasks if t['status'] == 'completed')
        
        # 3. Calculate Individual Contributions
        contribution_data = []
        for member in members:
            # Filter tasks assigned to this specific member
            member_tasks = [t for t in tasks if t['member_id'] == member['id']]
            m_total = len(member_tasks)
            m_completed = sum(1 for t in member_tasks if t['status'] == 'completed')
            
            # Calculate percentage of total project tasks completed by this member
            percentage = round((m_completed / total_tasks * 100), 1) if total_tasks > 0 else 0.0
            
            contribution_data.append({
                "member_id": member['id'],
                "member_name": member['name'],
                "assigned_tasks": m_total,
                "completed_tasks": m_completed,
                "contribution_percentage": percentage
            })
            
        return jsonify({
            "project_name": project['project_name'],
            "total_tasks": total_tasks,
            "completed_tasks": completed_tasks,
            "contributions": contribution_data
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    print(f"Connecting to database at: {DB_PATH}")
    app.run(port=5001, debug=True)
