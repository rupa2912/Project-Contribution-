"""
seed_test.py — Run this ONLY if Member 2's Node server hasn't created the DB yet.
Creates a minimal database.db inside backend-node/ so you can test the analytics
endpoint independently.
"""
import sqlite3
import os

DB_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '../backend-node/database.db'))
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

conn = sqlite3.connect(DB_PATH)
cur = conn.cursor()

# --- Schema (mirrors Member 2's Node setup) ---
cur.executescript("""
    CREATE TABLE IF NOT EXISTS projects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_name TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        FOREIGN KEY (project_id) REFERENCES projects(id)
    );
    CREATE TABLE IF NOT EXISTS tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        member_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        FOREIGN KEY (project_id) REFERENCES projects(id),
        FOREIGN KEY (member_id) REFERENCES members(id)
    );
""")

# --- Seed Data ---
cur.execute("INSERT INTO projects (project_name) VALUES ('Group Contribution Tracker')")
project_id = cur.lastrowid

cur.execute("INSERT INTO members (project_id, name) VALUES (?, 'Alice')", (project_id,))
alice_id = cur.lastrowid
cur.execute("INSERT INTO members (project_id, name) VALUES (?, 'Bob')", (project_id,))
bob_id = cur.lastrowid
cur.execute("INSERT INTO members (project_id, name) VALUES (?, 'Charlie')", (project_id,))
charlie_id = cur.lastrowid

tasks = [
    (project_id, alice_id,   'Set up React app',         'completed'),
    (project_id, alice_id,   'Build dashboard UI',       'completed'),
    (project_id, alice_id,   'Connect to APIs',          'pending'),
    (project_id, bob_id,     'Initialize Node server',   'completed'),
    (project_id, bob_id,     'Create CRUD endpoints',    'completed'),
    (project_id, bob_id,     'Write DB migrations',      'completed'),
    (project_id, charlie_id, 'Set up Flask service',     'completed'),
    (project_id, charlie_id, 'Analytics endpoint',       'completed'),
    (project_id, charlie_id, 'Git repo management',      'pending'),
]
cur.executemany(
    "INSERT INTO tasks (project_id, member_id, title, status) VALUES (?, ?, ?, ?)",
    tasks
)

conn.commit()
conn.close()
print(f"Test DB seeded at: {DB_PATH}")
print("Now run: python app.py")
print("Then visit: http://localhost:5001/api/analytics/1")
