# Member 3: Python Analytics + Git Lead

## Your Two Responsibilities

### 1. Git & Repository Management
You're the Version Control Lead — your job is to keep everyone synchronized.

#### Initial Setup (First 30 Minutes)
```bash
# Already done for you:
git init
git checkout -b main
git checkout -b dev
git checkout -b feature/python-analytics
```

#### Tell Your Teammates
- **Member 1:** Create branch `feature/react-frontend` from `dev`
- **Member 2:** Create branch `feature/node-crud` from `dev`

#### Workflow
- Everyone commits to their feature branch every 45–60 minutes
- At **Hour 5:** merge all features into `dev` for integration testing
- At **EOD:** merge `dev` → `main` for demo

### 2. Python Analytics Microservice

#### Installation
```bash
cd backend-python
pip install -r requirements.txt
```

#### Files
- `app.py` — Flask server with analytics endpoint
- `seed_test.py` — Creates test DB (use ONLY if Node server isn't ready)
- `requirements.txt` — Python dependencies

#### Test Without Node Server
```bash
python seed_test.py    # Creates ../backend-node/database.db
python app.py          # Runs Flask on port 5001
```

Visit: http://localhost:5001/api/analytics/1

#### Test With Node Server
Make sure Member 2's Node server is running first (creates `database.db`).

```bash
python app.py
```

#### What It Does
- Reads the same SQLite database that Member 2's Node server writes to
- Calculates:
  - Total tasks in the project
  - Completed tasks per member
  - Contribution percentage (completed tasks / total tasks × 100)
- Returns JSON for Member 1's React dashboard

#### Example Response
```json
{
  "project_name": "Group Contribution Tracker",
  "total_tasks": 9,
  "completed_tasks": 7,
  "contributions": [
    {
      "member_id": 1,
      "member_name": "Alice",
      "assigned_tasks": 3,
      "completed_tasks": 2,
      "contribution_percentage": 22.2
    },
    {
      "member_id": 2,
      "member_name": "Bob",
      "assigned_tasks": 3,
      "completed_tasks": 3,
      "contribution_percentage": 33.3
    },
    {
      "member_id": 3,
      "member_name": "Charlie",
      "assigned_tasks": 3,
      "completed_tasks": 2,
      "contribution_percentage": 22.2
    }
  ]
}
```

## Integration Checklist

- [ ] Member 2's Node server is running (creates database.db)
- [ ] `database.db` exists in `backend-node/` folder
- [ ] Python Flask runs on port 5001
- [ ] CORS is enabled (React on port 5173 can access it)
- [ ] Test the endpoint with Postman or browser
- [ ] Member 1's React dashboard calls this endpoint

## Commit Schedule

```bash
# Hour 1
git add app.py requirements.txt
git commit -m "feat: initial Flask analytics service"

# Hour 2
git add seed_test.py
git commit -m "feat: add test DB seeder for independent testing"

# Hour 3
# Test integration with Node server
git commit -m "fix: verify DB path resolution"

# Hour 4
# Performance optimization or error handling improvements
git commit -m "refactor: add error handling for missing projects"

# Hour 5
git checkout dev
git merge feature/python-analytics --no-ff
# Help teammates merge their branches too
```

## Troubleshooting

**Error: `database.db` not found**
- Run `python seed_test.py` to create a test DB, OR
- Make sure Member 2's Node server has run at least once

**Error: CORS policy blocking React**
- Verify `CORS(app)` is in `app.py`
- Check React is calling `http://localhost:5001` (not 3001)

**Error: Percentage doesn't add up to 100%**
- That's expected! Each percentage is: (member's completed tasks / project's total tasks) × 100
- If 3 members each complete 2 out of 9 tasks: 2/9 = 22.2% each (total = 66.6%)
